"""Correspondance des canaux MESA / SHHS-1 vers les entrées SleepFM et OSF (plan validé le 13 novembre).

Préparé avant l'accès aux données. Les libellés EDF viennent de la documentation publique NSRR
et restent **à vérifier sur les premiers fichiers** : un libellé attendu introuvable, ou trouvé
deux fois, arrête la préparation au lieu d'être deviné.

Règle (validée le 13 novembre) : la règle IAH est figée, donc l'entrée doit ressembler le plus possible à
celle vue sur PhysioNet 2018. Un canal mis à zéro sur PhysioNet reste à zéro sur NSRR même
s'il existe (jambes, ronflement, EOG droit pour OSF). Un canal présent sur PhysioNet mais absent
sur NSRR est mis à zéro et signalé (dégradation attendue, mesurée par la confirmation).

Échelle : SleepFM reçoit les valeurs brutes du .mat PhysioNet. D'après les en-têtes (.hea),
elles valent 1 unité par µV pour l'EEG, l'EOG, l'EMG, l'ECG, les sangles et le débit, et
655,35 × % − 32768 pour la SaO2. Les sangles et le débit n'ont pas d'unité physique comparable
d'un appareil à l'autre : règle `physionet_median_scale` (validée le 13 novembre, voir plus bas).
"""

from __future__ import annotations

import numpy as np

from src.data.osf_input import OSF_CHANNELS
from src.data.osf_physionet2018 import PHYSIONET_TO_OSF

SLEEPFM_CHANNELS = (
    "F3-M2", "F4-M1", "C3-M2", "C4-M1", "O1-M2", "O2-M1", "E1-M2",
    "Chin1-Chin2", "ABD", "CHEST", "AIRFLOW", "SaO2", "ECG",
)  # fmt: skip

# Libellés EDF possibles par signal (documentation NSRR, à vérifier).
MESA_LABELS = {
    "EEG_C4_M1": ("EEG3",),
    "EOG_L": ("EOG-L",),
    "EMG_CHIN": ("EMG",),
    "ECG": ("EKG",),
    "THORAX": ("Thor",),
    "ABDOMEN": ("Abdo",),
    "THERMISTOR": ("Flow",),
    "NASAL_PRESSURE": ("Pres",),
    "SPO2": ("SpO2",),
}
SHHS1_LABELS = {
    "EEG_C3_M2": ("EEG(sec)", "EEG2", "EEG 2", "EEG sec"),
    "EEG_C4_M1": ("EEG",),
    "EOG_L": ("EOG(L)",),
    "EMG_CHIN": ("EMG",),
    "ECG": ("ECG",),
    "THORAX": ("THOR RES",),
    "ABDOMEN": ("ABDO RES",),
    "THERMISTOR": ("AIRFLOW", "NEW AIR", "new A/F"),
    "SPO2": ("SaO2",),
}
# UCDDB (PhysioNet, contrôle externe validé le 13 novembre) : libellés lus dans l'en-tête EDF.
UCDDB_LABELS = {
    "EEG_C3_M2": ("C3A2",),
    "EEG_C4_M1": ("C4A1",),
    "EOG_L": ("Lefteye",),
    "EMG_CHIN": ("EMG",),
    "ECG": ("ECG",),
    "THORAX": ("ribcage",),
    "ABDOMEN": ("abdo",),
    "THERMISTOR": ("Flow",),
    "SPO2": ("SpO2",),
}
COHORT_LABELS = {"mesa": MESA_LABELS, "shhs1": SHHS1_LABELS, "ucddb": UCDDB_LABELS}

# Entrée SleepFM -> signal NSRR. Absent = zéros. `AIRFLOW` : capteur PhysioNet non documenté.
SLEEPFM_SOURCES = {
    "mesa": {
        "C4-M1": "EEG_C4_M1", "E1-M2": "EOG_L", "Chin1-Chin2": "EMG_CHIN", "ABD": "ABDOMEN",
        "CHEST": "THORAX", "AIRFLOW": "THERMISTOR", "SaO2": "SPO2", "ECG": "ECG",
    },
    "shhs1": {
        "C3-M2": "EEG_C3_M2", "C4-M1": "EEG_C4_M1", "E1-M2": "EOG_L", "Chin1-Chin2": "EMG_CHIN",
        "ABD": "ABDOMEN", "CHEST": "THORAX", "AIRFLOW": "THERMISTOR", "SaO2": "SPO2", "ECG": "ECG",
    },
}  # fmt: skip
SLEEPFM_SOURCES["ucddb"] = SLEEPFM_SOURCES["shhs1"]
# Entrée OSF -> signal NSRR, limitée aux canaux non nuls sur PhysioNet (PHYSIONET_TO_OSF).
# `NP` : PhysioNet a fourni AIRFLOW ; on garde le même type de capteur (thermistance).
OSF_SOURCES = {
    "mesa": {
        "ECG": "ECG", "EMG_Chin": "EMG_CHIN", "ABD": "ABDOMEN", "THX": "THORAX", "NP": "THERMISTOR",
        "EOG_E1_A2": "EOG_L", "EEG_C4_A1": "EEG_C4_M1",
    },
    "shhs1": {
        "ECG": "ECG", "EMG_Chin": "EMG_CHIN", "ABD": "ABDOMEN", "THX": "THORAX", "NP": "THERMISTOR",
        "EOG_E1_A2": "EOG_L", "EEG_C3_A2": "EEG_C3_M2", "EEG_C4_A1": "EEG_C4_M1",
    },
}  # fmt: skip
OSF_SOURCES["ucddb"] = OSF_SOURCES["shhs1"]
UNCERTAIN = {"sleepfm": ("AIRFLOW",), "osf": ("NP",)}
# Entrées SleepFM mises à l'échelle par la règle des médianes PhysioNet, par cohorte : les sangles et
# le débit partout ; en plus, les voies électriques non calibrées d'UCDDB (en-tête 0 à 1, « NV »).
MEDIAN_SCALED = {
    "mesa": ("ABD", "CHEST", "AIRFLOW"),
    "shhs1": ("ABD", "CHEST", "AIRFLOW"),
    "ucddb": ("ABD", "CHEST", "AIRFLOW", "C3-M2", "C4-M1", "E1-M2", "Chin1-Chin2", "ECG"),
}
MODEL_CHANNELS = {"sleepfm": SLEEPFM_CHANNELS, "osf": OSF_CHANNELS}
MODEL_SOURCES = {"sleepfm": SLEEPFM_SOURCES, "osf": OSF_SOURCES}

VOLTAGE_TO_UV = {"uv": 1.0, "µv": 1.0, "mv": 1e3, "v": 1e6}
SAO2_GAIN, SAO2_BASELINE = 655.35, -32768.0  # en-tête PhysioNet 2018 : 655.35(-32768)/%


def _norm(label: str) -> str:
    return " ".join(label.strip().lower().split())


def find_signal(edf_labels: list[str], cohort: str, signal: str) -> int:
    """Indice unique du signal dans l'EDF ; erreur s'il manque ou s'il est ambigu."""
    wanted = {_norm(label) for label in COHORT_LABELS[cohort][signal]}
    hits = [i for i, label in enumerate(edf_labels) if _norm(label) in wanted]
    if len(hits) != 1:
        raise ValueError(f"{cohort} : signal {signal} trouvé {len(hits)} fois ({sorted(wanted)})")
    return hits[0]


def channel_plan(edf_labels: list[str], cohort: str, model: str) -> dict:
    """Pour chaque entrée du modèle : indice EDF ou None (zéros), avec le détail à publier."""
    if cohort not in COHORT_LABELS or model not in MODEL_CHANNELS:
        raise ValueError(f"Cohorte ou modèle inconnu : {cohort}, {model}")
    sources = MODEL_SOURCES[model][cohort]
    indices = {
        target: find_signal(edf_labels, cohort, sources[target]) if target in sources else None
        for target in MODEL_CHANNELS[model]
    }
    physionet_zero = set(OSF_CHANNELS) - set(PHYSIONET_TO_OSF) if model == "osf" else set()
    return {
        "indices": indices,
        "zero_filled": [t for t, i in indices.items() if i is None],
        "lost_vs_physionet": [t for t, i in indices.items() if i is None and t not in physionet_zero],
        "uncertain": [t for t in UNCERTAIN[model] if indices.get(t) is not None],
    }


def to_physionet_scale(signal: np.ndarray, unit: str, target: str) -> np.ndarray:
    """Remet un signal NSRR à l'échelle des valeurs brutes PhysioNet vues par SleepFM."""
    unit_key = _norm(unit)
    if target == "SaO2":
        if unit_key != "%":
            raise ValueError(f"SaO2 en % attendue, reçu {unit!r}")
        return SAO2_GAIN * np.asarray(signal, dtype=np.float64) + SAO2_BASELINE
    if target in ("ABD", "CHEST", "AIRFLOW"):
        raise ValueError(f"{target} : échelle non comparable entre appareils, utiliser physionet_median_scale")
    if unit_key not in VOLTAGE_TO_UV:
        raise ValueError(f"{target} : unité de tension attendue, reçu {unit!r}")
    return VOLTAGE_TO_UV[unit_key] * np.asarray(signal, dtype=np.float64)


# Règle validée par le tuteur le 13 novembre 2026 : échelle robuste (1,4826 × écart absolu médian)
# de chaque nuit NSRR ramenée à la médiane des 360 nuits d'apprentissage PhysioNet
# (results/respiratory_amplitude_physionet2018.json, docs/resultats/respiratoire_amplitude_sangles_2026-11-13.md).
PHYSIONET_MEDIAN_SCALE = {"ABD": 172.72289999999998, "CHEST": 83.0256, "AIRFLOW": 13.343399999999999}
# Voies électriques non calibrées (UCDDB, contrôle externe validé le 13 novembre) : médianes des
# 360 mêmes nuits (results/eeg_amplitude_physionet2018.json, plan « amplitude EEG EOG EMG ECG »).
PHYSIONET_MEDIAN_SCALE |= {'C3-M2': 11.8608, 'C4-M1': 11.8608, 'E1-M2': 11.8608, 'Chin1-Chin2': 2.9652, 'ECG': 80.0604}


def robust_scale(signal: np.ndarray) -> float:
    x = np.asarray(signal, dtype=np.float64)
    return float(1.4826 * np.median(np.abs(x - np.median(x))))


def physionet_median_scale(target: str, signal: np.ndarray, unit: str) -> np.ndarray:
    """Règle v1 (13 novembre), conservée pour la trace : amplitude seule, sans recentrage.

    Défaut trouvé sur UCDDB : une voie dont la ligne de base est loin de zéro le reste, alors que
    les voies PhysioNet sont centrées sur 0. Remplacée par `physionet_median_centered_scale`.
    """
    return _median_scale(target, signal)


def physionet_median_centered_scale(target: str, signal: np.ndarray, unit: str) -> np.ndarray:
    """Règle v2 (16 novembre) : voie recentrée sur sa médiane de la nuit, puis échelle robuste
    ramenée à la médiane PhysioNet. Les voies PhysioNet concernées ont une médiane proche de 0
    (results/*amplitude_physionet2018.json, « median_of_medians »)."""
    x = np.asarray(signal, dtype=np.float64)
    return _median_scale(target, x - np.median(x))


def _median_scale(target: str, signal: np.ndarray) -> np.ndarray:
    """Signal multiplié pour que son échelle robuste égale la médiane PhysioNet de la voie."""
    if target not in PHYSIONET_MEDIAN_SCALE:
        raise ValueError(f"{target} : pas de médiane PhysioNet établie pour cette voie")
    scale = robust_scale(signal)
    if not scale > 0:
        raise ValueError(f"{target} : échelle robuste nulle, canal refusé")
    return np.asarray(signal, dtype=np.float64) * (PHYSIONET_MEDIAN_SCALE[target] / scale)
